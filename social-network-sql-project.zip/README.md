# Social Network – SQL Database Project

Final project in the "Advanced Databases" course – Ono Academic College (2025)  
This project simulates a database for a social network and includes:

## 📄 Content
- Creation of a normalized relational database structure (DDL)
- Data population (DML), constraints, updates, deletes
- Analytical SQL queries: aggregation, joins, filtering, subqueries
- Advanced queries for user engagement, post popularity, and interaction analysis
- A dedicated View to summarize user activity
- A Trigger to automatically assign age groups based on birthdate

## 🧰 Technologies
- SQL (DDL + DML + Views + Triggers)
- Microsoft SQL Server / Azure Data Studio
- PDF documentation (Exercises 1–3)

## 📁 Files
- `Exercise1.pdf` – Database structure and DDL/DML (Table creation & inserts)
- `Exercise2.pdf` – Query exercises for user, post, comment, like analysis
- `Exercise3.pdf` – Advanced project queries including triggers, views, user segmentation

